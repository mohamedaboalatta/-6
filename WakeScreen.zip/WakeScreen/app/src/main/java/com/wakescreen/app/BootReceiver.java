package com.wakescreen.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        Prefs p = new Prefs(c);
        if (p.enabled()) Scheduler.schedule(c);
        if (p.volumeWake()) c.startForegroundService(new Intent(c, VolumeKeyService.class));
    }
}
